# Frameworks_Assignment

## Overview
This project explores the **CORD-19 metadata.csv dataset** to understand trends in COVID-19 research papers.  
It includes data cleaning, visualization, and an interactive Streamlit web app.

## Tools Used
- Python 3.7+
- pandas
- matplotlib & seaborn
- wordcloud
- Streamlit

## Project Structure
```
Frameworks_Assignment/
│── data/metadata.csv
│── notebooks/cord19_analysis.ipynb
│── app/streamlit_app.py
│── README.md
```

## How to Run
1. Clone this repo  
2. Install dependencies:
   ```bash
   pip install pandas matplotlib seaborn streamlit wordcloud
   ```
3. Run Jupyter Notebook for analysis:
   ```bash
   jupyter notebook notebooks/cord19_analysis.ipynb
   ```
4. Run the Streamlit app:
   ```bash
   streamlit run app/streamlit_app.py
   ```

## Insights
- Publication activity spiked in 2020–2021.
- Certain journals dominated COVID-19 publications.
- Frequent words in paper titles included *COVID, SARS-CoV, pandemic*.
- Different sources contributed varying numbers of papers.

## Reflection
This assignment improved skills in:
- Handling real-world datasets
- Cleaning and transforming data
- Visualizing research trends
- Deploying findings interactively via Streamlit
