import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud

@st.cache_data
def load_data():
    df = pd.read_csv("../data/metadata.csv")
    df['publish_time'] = pd.to_datetime(df['publish_time'], errors='coerce')
    df['year'] = df['publish_time'].dt.year
    df['abstract_word_count'] = df['abstract'].fillna("").apply(lambda x: len(x.split()))
    return df

df = load_data()

st.title("📊 CORD-19 Data Explorer")
st.write("Simple exploration of COVID-19 research papers (metadata.csv)")

years = df['year'].dropna().astype(int).unique()
min_year, max_year = int(min(years)), int(max(years))
year_range = st.slider("Select year range:", min_year, max_year, (2020, 2021))

filtered_df = df[(df['year'] >= year_range[0]) & (df['year'] <= year_range[1])]

st.subheader("Sample Data")
st.dataframe(filtered_df[['title', 'journal', 'year']].head(10))

st.subheader("Publications Over Time")
year_counts = filtered_df['year'].value_counts().sort_index()
fig, ax = plt.subplots()
sns.barplot(x=year_counts.index, y=year_counts.values, color="skyblue", ax=ax)
ax.set_title("Publications by Year")
st.pyplot(fig)

st.subheader("Top Journals")
top_journals = filtered_df['journal'].value_counts().head(10)
fig, ax = plt.subplots()
sns.barplot(y=top_journals.index, x=top_journals.values, color="lightgreen", ax=ax)
ax.set_title("Top 10 Journals")
st.pyplot(fig)

st.subheader("Word Cloud of Titles")
titles = " ".join(filtered_df['title'].dropna().tolist())
wordcloud = WordCloud(width=800, height=400, background_color="white").generate(titles)
fig, ax = plt.subplots(figsize=(10,5))
ax.imshow(wordcloud, interpolation="bilinear")
ax.axis("off")
st.pyplot(fig)
